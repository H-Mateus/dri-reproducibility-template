## Directory purpose

This is to house files related to the management of the project.
