## Directory purpose

This is to house protocols. 
Not so sure about how to approach the code sub-dir VS keeping code in the `04_data_analysis` directory...
