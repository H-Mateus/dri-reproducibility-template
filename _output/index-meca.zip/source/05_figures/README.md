## Directory purpose

This is to house figures generated from each experiment in respective sub-folders, and a shared directory for figures that span experiments
