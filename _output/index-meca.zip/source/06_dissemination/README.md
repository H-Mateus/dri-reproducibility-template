## Directory purpose

This is to house files to disseminated (papers, posters, talks, etc).
